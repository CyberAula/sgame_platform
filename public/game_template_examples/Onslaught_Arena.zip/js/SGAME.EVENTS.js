var SGAME = SGAME || {};

SGAME.EVENTS_LIST = {
	"events":
	[
		{
			"id": 1,
			"name":"Extra Weapon",
			"description":"Get an extra weapon to kill stronger monsters",
			"type": SGAME.EVENT.EXTRA_ITEM
		},
		{
			"id": 2,
			"name":"A generic event",
			"description":"Integrate SCORM into web games with SGAME API",
			"type": SGAME.EVENT.GENERIC
		}
	]
};