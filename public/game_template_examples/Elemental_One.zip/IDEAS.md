Game Ideas (Ludum Dare 28)
==========================

## Theme: You Only Get One

## Abstract Ideas
- One power / ability (acquired from item?)
- One tool (survival simulator?)
- One programmable shot (you are a robot?)
- One binary digit (binary arithmetic game?)
- One body (ethereal entity, possess creatures to complete level?)

## THE CHOICE
- One power! Elemental. Puzzle-platformer
