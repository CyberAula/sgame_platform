var SGAME = SGAME || {};

SGAME.EVENTS_LIST = {
	"events":
	[
		{
			"id": 1,
			"name":"Extra Life",
			"description":"Event triggered when the devil catches the player",
			"type": SGAME.EVENT.EXTRA_LIFE
		}
	]
};