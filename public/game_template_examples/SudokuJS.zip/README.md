# sudoku-js
A game of Sudoku as a mobile app

Original source code available at https://github.com/baruchel/sudoku-js.

The game may be tried at (http://baruchel.insomnia247.nl/sudoku-js/sudoku.html).
